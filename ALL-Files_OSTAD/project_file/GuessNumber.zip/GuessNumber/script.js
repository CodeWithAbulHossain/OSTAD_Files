'use strict';
// score
let score = 20;
// highScore

let highScore = localStorage.getItem('highScore')
  ? localStorage.getItem('highScore')
  : 0;
// select all elements
let inputNumber = document.querySelector('.guess');
let correctNumber = document.querySelector('.number');
let msg = document.querySelector('.message');
let scoreMsg = document.querySelector('.score');
let highscoreMsg = document.querySelector('.highscore');
let checkBtn = document.querySelector('.check');
let againBtn = document.querySelector('.againBtn');
highscoreMsg.textContent = highScore;
// create number between 1 and 20
let randomNumber = Math.floor(Math.random() * 20) + 1;

// add event on button
checkBtn.addEventListener('click', guessNumber);
// reset game
againBtn.addEventListener('click', resetGame);

// guess number function
function guessNumber() {
  let userNumber = Number(inputNumber.value);
  if (score === 0) {
    msg.textContent = '😔 You lose the game';
    correctNumber.textContent = randomNumber;
  } else {
    if (randomNumber === userNumber) {
      msg.textContent = '🎉 Correct Number';
      scoreMsg.textContent = score;

      highScore = score > highScore ? score : highScore;
      localStorage.setItem('highScore', highScore);
      highscoreMsg.textContent = highScore;
      inputNumber.value = '';
      correctNumber.textContent = randomNumber;
      document.body.style.backgroundColor = 'var(--bg-light)';
    } else if (userNumber > randomNumber && userNumber < 20) {
      score -= 2;
      msg.textContent = '😔 Too High';
      scoreMsg.textContent = score;
      inputNumber.value = '';
    } else if (userNumber < randomNumber && userNumber > 0) {
      score -= 2;
      msg.textContent = '😔 Too Low';
      scoreMsg.textContent = score;
      inputNumber.value = '';
    } else {
      msg.textContent = '😡 Number between 1 and 20';
      inputNumber.value = '';
    }
  }
}

// reset game
function resetGame() {
  score = 20;
  msg.textContent = 'Start guessing...';
  inputNumber.value = '';
  correctNumber.textContent = '?';
  scoreMsg.textContent = 20;
  randomNumber = Math.floor(Math.random() * 20) + 1;
  document.body.style.backgroundColor = 'var(--bg-dark)';
}
